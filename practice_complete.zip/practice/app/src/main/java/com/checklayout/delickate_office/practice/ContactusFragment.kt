package com.checklayout.delickate_office.practice

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.graphics.Bitmap
import android.os.AsyncTask
import android.util.Log
import android.widget.*
import kotlinx.android.synthetic.main.fragment_contactus.view.*
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import android.graphics.drawable.BitmapDrawable




// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [ContactusFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [ContactusFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class ContactusFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var listener: OnFragmentInteractionListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view: View = inflater!!.inflate(R.layout.fragment_contactus, container, false)

        ///////////////////////// SPINNER /////////////////////////
        val spinner: Spinner =  view.findViewById(R.id.spinner_education)
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
                activity,
                R.array.education_array,
                android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
        }

        //////////////////////////////////////////////////
        ///////////////////////// FILE UPLOAD /////////////////////////

        val file_upload: Button =  view.findViewById(R.id.file_upload)

        file_upload.setOnClickListener {
            selectImageFromGallery()
           // selectImageFromCamera()
        }
        ///////////////////////////////////////////////////////////////


        ///////////////////////// Submit data to URL /////////////////////////
        var field_name : EditText = view.findViewById(R.id.txtName)
        var field_subject : EditText = view.findViewById(R.id.txtSubject)
        var field_gender: Int = view.radio_group.checkedRadioButtonId
        var field_education: Spinner = view.findViewById(R.id.spinner_education)
        var field_interest : String
        var field_interest_1: CheckBox = view.findViewById(R.id.checkbox_reading)
        var field_interest_2: CheckBox = view.findViewById(R.id.checkbox_games)
        var field_message : EditText = view.findViewById(R.id.textarea_message)
        var field_fileupload : ImageView = view.findViewById(R.id.selected_file)

        var form_submit : Button = view.findViewById(R.id.btnSubmit)

        form_submit.setOnClickListener {

            var name = field_name.text  //SANI: Textbox /EditText
            var subject = field_subject.text //SANI: Textbox/EditText
            var gender = "";
            //SANI: Radio Button
            if (field_gender!=-1){ // If any radio button checked from radio group
                // Get the instance of radio button using id
                val selected_gender:RadioButton = view.findViewById(field_gender)  //SANI: RadioButton
                gender = selected_gender.text.toString()

            }

            var education = field_education.getSelectedItem().toString() //SANI: Select/dropdown/spinner

            //SANI: Checkbox
            field_interest = ""
            if (field_interest_1.isChecked)
                field_interest += ""+field_interest_1.text +","
            if (field_interest_2.isChecked)
                field_interest += ""+field_interest_2.text +""

            var interest = field_interest
            //SANI: Text area
            var message = field_message.text

            val bitMap : Bitmap =field_fileupload.getDrawingCache();
            var fileupload = field_fileupload.setImageBitmap(convertImageViewToBitmap(field_fileupload));

            //////////////////// FILE UPLOAD ///////////////////////

            ///////////////////////////////////////////

            //SANI: Creating Json String of data
            val json = JSONObject()
            json.put("name", name)
            json.put("subject", subject)
            json.put("gender", gender)
            json.put("education", education)
            json.put("interest", interest)
            json.put("message", message)

            //SANI: Creating Query string
            var query_string = "name="+name+"&subject="+subject+"&gender="+gender+"&education="+education+"&interest="+interest+"&message="+message+"&fileupload="+fileupload

            val error_message:TextView  = view.findViewById(R.id.errormessage_contactus) as TextView

            var livevar = "http://www.go4smart.com/Api/savedata"

            //SANI: Calling task class
            ContactusFragment.HttpTask({

                if (it == null) {
                    // println("connection error")
                    return@HttpTask
                }
                 Log.v("response", it)


                var json = JSONObject(it)
                val getstatus = json.get("status")

                if (getstatus == "error") {
                    var getmessage = json.get("data")

                    error_message.text = getmessage.toString()
                } else {
                    error_message.text = "Success"
                    var getmessage = json.get("data")
                    error_message.text = getmessage.toString()
                }

            }).execute("POST", livevar, query_string.toString())


        }
        ///////////////////////////////////////////////////////////////
        // Inflate the layout for this fragment
       //return inflater.inflate(R.layout.fragment_contactus, container, false)

        return view
    }

    private fun convertImageViewToBitmap(v: ImageView): Bitmap {

        return (v.drawable as BitmapDrawable).bitmap
    }
    ///////////////////SANI: File upload from gallery ////////////////////////
    fun selectImageFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        if (intent.resolveActivity(getActivity()!!.getPackageManager()) != null) {
            //startActivityForResult(intent, REQUEST_SELECT_IMAGE_IN_ALBUM)
            startActivityForResult(intent, REQUEST_SELECT_IMAGE_IN_ALBUM);
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        val image_view: ImageView =  view!!.findViewById(R.id.selected_file)
        if (requestCode == REQUEST_SELECT_IMAGE_IN_ALBUM && resultCode == RESULT_OK) {
            val imageUri = data!!.data
            image_view.setImageURI(imageUri)

        }
    }

    ///////////////////SANI: END: File upload from gallery ////////////////////////

    //////////////////SANI: File upload from Camera ///////////////////////////////
/*    fun selectImageFromCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val frag = this


        if (intent.resolveActivity(getActivity()!!.getPackageManager()) != null) {
            frag.startActivityForResult(intent, REQUEST_TAKE_PHOTO)
        }
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                // Do something with imagePath
                val image_view: ImageView =  view!!.findViewById(R.id.selected_file)
                val photo = data!!.extras!!.get("data") as Bitmap
                image_view.setImageBitmap(photo)
                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
               // var selectedImage = getImageUri(activity, photo)
               // val realPath = getRealPathFromURI(selectedImage)
               // selectedImage = Uri.parse(realPath)
            }
        }
    }
*/
    ///////////////////SANI: END: File upload from Camera ////////////////////////

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri) {
        listener?.onFragmentInteraction(uri)
    }

    /*
    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }
*/
    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ContactusFragment.
         */

        private val REQUEST_TAKE_PHOTO = 0
        private val REQUEST_SELECT_IMAGE_IN_ALBUM = 1
        private val REQUEST_IMAGE_CAPTURE = 0

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                ContactusFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }


    class HttpTask(callback: (String?) -> Unit) : AsyncTask<String, Unit, String>()  {

        var callback = callback

        override fun doInBackground(vararg params: String): String? {
            val boundary: String
            boundary = "===" + System.currentTimeMillis() + "===";

            val url = URL(params[1])
            val httpClient = url.openConnection() as HttpURLConnection
            httpClient.setReadTimeout(60000)
            httpClient.setConnectTimeout(60000)
            httpClient.requestMethod = params[0]

            if (params[0] == "POST") {
                httpClient.instanceFollowRedirects = false
                httpClient.doOutput = true
                httpClient.doInput = true
                httpClient.useCaches = false

                httpClient.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                httpClient.setRequestProperty("charset", "utf-8");
                httpClient.setRequestProperty("SANI-API-KEY", "200ceb26807d6bf99fd6f4f0d1ca54d4");
                //httpClient.setRequestProperty("Content-Length", Integer.toString(params.getBytes().length));
            }
            try {
                if (params[0] == "POST") {
                    httpClient.connect()
                    val os = httpClient.getOutputStream()
                    val writer = BufferedWriter(OutputStreamWriter(os, "UTF-8"))
                    writer.write(params[2])
                    writer.flush()
                    writer.close()
                    os.close()
                }
                if (httpClient.responseCode == HttpURLConnection.HTTP_OK) {
                    val stream = BufferedInputStream(httpClient.inputStream)
                    val data: String = readStream(inputStream = stream)
                    //Log.v("response", data)
                    // val error_message = findViewById<View>(R.id.errormessage) as TextView
                    //////////////////////////////////////////////////
                    //var json = JSONObject(data)
                    //Log.v("response", json.toString())
                    //val getstatus = json.get("status")

                    //Log.v("response", getstatus.toString())

                    //if(getstatus == "error")
                    //{
                    //    var getmessage = json.get("data")
                    //error_message.text = getmessage.toString()
                    //}else{
                    //error_message.text = "Success"
                    //startActivity(Intent(this@MainActivity,dashboardActivity::class.java))
                    //}
                    //////////////////////////////////////////////////
                    return data
                } else {
                    return ""
                    //println("ERROR ${httpClient.responseCode}")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                httpClient.disconnect()
            }

            return null
        }

        fun readStream(inputStream: BufferedInputStream): String {
            val bufferedReader = BufferedReader(InputStreamReader(inputStream))
            val stringBuilder = StringBuilder()
            bufferedReader.forEachLine { stringBuilder.append(it) }
            return stringBuilder.toString()
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            callback(result)
        }
    }
}
