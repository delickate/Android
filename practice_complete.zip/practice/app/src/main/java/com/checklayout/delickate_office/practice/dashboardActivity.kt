package com.checklayout.delickate_office.practice

import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.ActionBar
import android.util.Log
import android.widget.Button
import java.io.*
import java.net.HttpURLConnection
import java.net.URL


class dashboardActivity : AppCompatActivity() {

    lateinit var toolbar: ActionBar //SANI: For bottom navigation



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        setTitle("Dashboard")

        //SANI: Initialization of bottom navigation
        toolbar = supportActionBar!!
        val bottomNavigation: BottomNavigationView = findViewById(R.id.navigationView)

        //Initialization of bottom navigation listener
        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)


        /////////////// BUTTONS DASHBOARD /////////////////////////
        val btn_home: Button = findViewById(R.id.btn_home)
        val btn_databases: Button = findViewById(R.id.btn_databases)
        val btn_contactus: Button = findViewById(R.id.btn_contactus)

        btn_home.setOnClickListener {
            toolbar.title = "Home"
            val homeFragment = homeFragment.newInstance("1","2")
            openFragment(homeFragment)
        }

        btn_databases.setOnClickListener {
            toolbar.title = "Databases"
            val dbFragment = DatabasesFragment.newInstance("1","2")
            // val dbFragment = DatabasesFragment()
            openFragment(dbFragment)
        }

        btn_contactus.setOnClickListener {
            toolbar.title = "Contact Us"
            val contactusFragment = ContactusFragment.newInstance("1","2")
            //val contactusFragment = DatabasesFragment()
            openFragment(contactusFragment)
        }


    }

    //SANI: Click event bottom navigation
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                toolbar.title = "Home"
                val homeFragment = homeFragment.newInstance("1","2")
                openFragment(homeFragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_databases -> {

                toolbar.title = "Databases"
                val dbFragment = DatabasesFragment.newInstance("1","2")
               // val dbFragment = DatabasesFragment()
                openFragment(dbFragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_contactus -> {
                toolbar.title = "Contact Us"
                val contactusFragment = ContactusFragment.newInstance("1","2")
                //val contactusFragment = DatabasesFragment()
                openFragment(contactusFragment)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    //SANI: Opening clicked fragment
    private fun openFragment(fragment: Fragment) {

        val detailsFragment =

        supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment, "rageComicDetails")
                .addToBackStack(null)
                .commit()

        //val transaction = supportFragmentManager.beginTransaction()
        //transaction.replace(R.id.container, fragment)
        //transaction.addToBackStack(null)
        //transaction.commit()
        Log.v("SANI","Fragment clicked"+R.id.container)
    }



}
