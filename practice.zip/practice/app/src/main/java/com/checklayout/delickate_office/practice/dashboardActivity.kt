package com.checklayout.delickate_office.practice

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class dashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
    }
}
